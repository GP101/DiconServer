## Runs all the build binaries from bin/ folder

find bin/ -name '*.cpp.bin' -exec sh ./run.sh ./{} \;
