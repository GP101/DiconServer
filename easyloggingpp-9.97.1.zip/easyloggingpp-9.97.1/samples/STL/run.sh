echo "Running '$1'..."
./$1 -v
echo "Finished '$1'"
echo
