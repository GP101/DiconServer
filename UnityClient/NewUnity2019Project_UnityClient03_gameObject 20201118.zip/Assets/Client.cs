﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net;
using System.Drawing;
using UnityEngine;
using TcpInteract;
using DemoShared;
using DemoClient;

public class Client : MonoBehaviour
{
    private MessengerClient client = null;
    private string _serverIp = "127.0.0.1";
    private const int PORT = 2059;
    private string _clientName = "client1";
    private bool _isSyncPosition = true;
    [SerializeField]
    private GameObject _playerPrefab;
    private Vector3 _position; // local player position

    // Start is called before the first frame update
    void Start()
    {
        client = new MessengerClient();
        LoadSettings();

        client.StatusChanged += ClientStatusChanged;
        client.Pusher.Bind<ServerClosedContent>(content =>
        {
            Debug.Log("The server has closed.");
        });
        client.Pusher.Bind<ConnectionRefusedContent>(ClientOnConnectionRefused);
        client.Pusher.Bind<LoginContent>(ClientOnClientLoggedIn);
        client.Pusher.Bind<LogoutContent>(ClientOnClientLoggedOut);
        client.Pusher.Bind<InstantMessageContent>(ClientOnInstantMessage);
        client.OnPlayerChanged += OnPlayerChanged;

        StartCoroutine(SyncPosition());
    }

    // Update is called once per frame
    void Update()
    {
        // qff. client position must be updated here. 20201118_jintaeks
        _position = transform.position;
    }

    private void OnDestroy()
    {
        client.Logout();
        client.Dispose();
    }

    private static void ShowErrorMessage(string message)
    {
        Debug.Log(message);
    }

    private void LoadSettings()
    {
    }

    private void ClientStatusChanged(object sender, EventArgs e)
    {
        switch (client.Status)
        {
            case ClientStatus.Connected:
                Debug.Log("Connected. Awaiting login approval.");
                break;

            case ClientStatus.Disconnected:
                Debug.Log("Idle.");
                break;

            case ClientStatus.LoggedIn:
                Debug.Log("Logged in." + client.Name);
                client.Synchronize();
                break;
        }
    }

    private void ClientOnClientLoggedIn(LoginContent content)
    {
        Debug.Log($@"{content.ClientName}: logged in.");
    }

    private void ClientOnClientLoggedOut(LogoutContent content)
    {
        string message;

        switch (content.Reason)
        {
            case LogoutReason.Kicked:
                message = $@"{content.ClientName}: was kicked. Reason: {content.Message}";

                if (content.ClientName == client.Name)
                {
                    Debug.Log($"You have been kicked.\nReason: {content.Reason}.");
                }
                break;

            case LogoutReason.TimedOut:
                message = $@"{content.ClientName}: timed out.";
                break;

            case LogoutReason.UserSpecified:
                message = $@"{content.ClientName}: logged out.";
                break;

            default:
                throw new InvalidEnumArgumentException();
        }

        Debug.Log(message);
    }

    private void ClientOnConnectionRefused(ConnectionRefusedContent e)
    {
        Debug.Log("Connection refused: " + e.Reason);
    }

    private void RequestLogin()
    {
        IPAddress address;

        try
        {
            address = IPAddress.Parse(_serverIp);
        }
        catch (FormatException)
        {
            ShowErrorMessage("Invalid address format.");
            return;
        }

        client.Name = _clientName;
        client.EndPoint = new IPEndPoint(address, PORT);

        try
        {
            client.RequestLogin();
        }
        catch (InvalidOperationException ex)
        {
            Debug.Log(ex.Message);
        }
        catch (AlreadyLoggedInException ex)
        {
            Debug.Log(ex.Message);
        }
    }
    private void ClientOnInstantMessage(InstantMessageContent content)
    {
        Debug.Log(content.Message);
    }

    IEnumerator SyncPosition()
    {
        while (_isSyncPosition)
        {
            if (client.CanSendPackage())
            {
                Point p = new Point((int)_position.x, (int)_position.z);
                var args = new ClientCursorContent(p, client.Name);
                client.SendPackageAsync((int)Commands.CursorPosition, args);
            }
            yield return new WaitForSeconds(0.1f);
        }
    }

    void OnPlayerChanged(string name, int reason)
    {
        if (reason == 0)
        {
            GameObject go = GameObject.Find(name);
            GameObject.Destroy(go);
        }
        else if (reason == 1)
        {
            GameObject go = Instantiate(_playerPrefab
                , new Vector3(UnityEngine.Random.Range(-5.0f, +5.0f), 1.0f, UnityEngine.Random.Range(-5.0f, +5.0f))
                , Quaternion.identity);
            go.name = name;
        }
    }

    private void OnGUI()
    {
        _clientName = GUI.TextField(new Rect(0, 0, 160, 30), _clientName);
        _serverIp = GUI.TextField(new Rect(0, 30, 160, 30), _serverIp);
        if( GUI.Button(new Rect(0,60,80,30),"Connect") )
        {
            RequestLogin();
        }
    }
}
